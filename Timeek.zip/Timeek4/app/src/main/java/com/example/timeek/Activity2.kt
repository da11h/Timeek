package com.example.timeek


import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class Activity2: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)
    }

    fun startSecondActivity(view: View) {
        val intent = Intent(this, Activity3::class.java)
        startActivity(intent)
    }
}
