package com.example.timeek

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class Activity3: AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_3)
    }

    fun startActivity4(view: View) {
        val intent = Intent(this, Activity4::class.java)
        startActivity(intent)
    }

    fun startActivity5(view: View) {
        val intent = Intent(this, Activity5::class.java)
        startActivity(intent)
    }

    fun startActivity6(view: View) {
        val intent = Intent(this, Activity6::class.java)
        startActivity(intent)
    }
}